#!/bin/bash
git log --pretty=format:"%H" -n5
