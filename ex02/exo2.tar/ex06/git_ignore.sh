git ls-Files -i -o --excluded-Standard
